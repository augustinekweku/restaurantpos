<template>
    <div>
        <div class="_3border_color _footer_main px-3 mt-4 ">
            <div class="_footer_main_left text-center">
                <p class="_footer_copy"> Developed by <strong> <a target="_blank" href="https://augustinenani.netlify.app/"> Nanitech</a> </strong> &copy; 2021 All rights reserved.</p>
            </div>

            <div class="_footer_main_right">
                <ul class="_footer_list">
                    <li>
                        <a href="">Privecy</a>
                    </li>
                    <li>
                        <a href="">Policy</a>
                    </li>
                    <li>
                        <a href="">Terms</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</template>
<style scoped>
._footer_main{

    width: 100%;
  position: fixed;
  z-index: 999;
  bottom: 1px;
  text-align: center;
  background: white;
  /* box-shadow: 0px 0px 5px 0px rgba(0,0,0,0.75); */
}
</style>